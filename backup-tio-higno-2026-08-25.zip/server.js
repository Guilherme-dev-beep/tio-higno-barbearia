const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { URL } = require('url');

const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const PUBLIC = path.join(ROOT, 'public');
const DB_PATH = path.join(ROOT, 'data', 'db.json');
const MIME = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'application/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.ico':'image/x-icon'};

const readDb = () => JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
const writeDb = db => fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
const clean = (v='', max=160) => String(v).replace(/[<>]/g,'').trim().slice(0,max);
const validDate = d => /^\d{4}-\d{2}-\d{2}$/.test(d||'');
const validTime = t => /^([01]\d|2[0-3]):[0-5]\d$/.test(t||'');
const toMin = t => { const [h,m]=t.split(':').map(Number); return h*60+m; };
const overlaps = (a,da,b,db) => { const a1=toMin(a), b1=toMin(b); return a1 < b1+Number(db) && b1 < a1+Number(da); };
async function sendWhatsAppConfirmation(booking,service,barber,settings){
  if(!settings.whatsappEnabled||!settings.whatsappToken||!settings.whatsappPhoneId)return;
  const phone=String(booking.phone).replace(/\D/g,'');
  const recipient=phone.length===10||phone.length===11?'55'+phone:phone;
  const version=settings.whatsappApiVersion||'v20.0';
  const template=settings.whatsappTemplate||'booking_confirmation';
  const payload={
    messaging_product:'whatsapp',
    to:recipient,
    type:'template',
    template:{
      name:template,
      language:{code:settings.whatsappLanguage||'pt_BR'},
      components:[{type:'body',parameters:[
        {type:'text',text:booking.name},
        {type:'text',text:service.name},
        {type:'text',text:new Date(`${booking.date}T12:00:00`).toLocaleDateString('pt-BR')},
        {type:'text',text:booking.time},
        {type:'text',text:barber.name}
      ]}]
    }
  };
  const response=await fetch(`https://graph.facebook.com/${version}/${settings.whatsappPhoneId}/messages`,{method:'POST',headers:{Authorization:`Bearer ${settings.whatsappToken}`,'Content-Type':'application/json'},body:JSON.stringify(payload)});
  if(!response.ok)throw new Error(`WhatsApp API retornou HTTP ${response.status}`);
}

function json(res, status, data){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(data));}
function parseBody(req){return new Promise((resolve,reject)=>{let body='';req.on('data',c=>{body+=c;if(body.length>1e6){req.destroy();reject(new Error('Payload muito grande'));}});req.on('end',()=>{if(!body)return resolve({});try{resolve(JSON.parse(body));}catch{reject(new Error('JSON inválido'));}});req.on('error',reject);});}
function adminOK(req){return req.headers['x-admin-password']===readDb().settings.adminPassword;}
function serveFile(req,res,pathname){let rel=pathname==='/'?'index.html':pathname==='/admin'?'admin.html':pathname.replace(/^\//,'');let file=path.normalize(path.join(PUBLIC,rel));if(!file.startsWith(PUBLIC))return false;if(!fs.existsSync(file)||!fs.statSync(file).isFile())return false;res.writeHead(200,{'Content-Type':MIME[path.extname(file)]||'application/octet-stream'});fs.createReadStream(file).pipe(res);return true;}

async function handleApi(req,res,url){
  const p=url.pathname, method=req.method;
  if(method==='GET'&&p==='/api/bootstrap'){
    const db=readDb(),{adminPassword,...settings}=db.settings;return json(res,200,{services:db.services.filter(s=>s.active),barbers:db.barbers.filter(b=>b.active),settings});
  }
  if(method==='GET'&&p==='/api/availability'){
    const date=url.searchParams.get('date'),barberId=url.searchParams.get('barberId'),serviceId=url.searchParams.get('serviceId');
    if(!validDate(date)||!barberId||!serviceId)return json(res,400,{error:'Parâmetros inválidos.'});
    const db=readDb(),barber=db.barbers.find(b=>b.id===barberId&&b.active),service=db.services.find(s=>s.id===serviceId&&s.active);
    if(!barber||!service)return json(res,404,{error:'Barbeiro ou serviço não encontrado.'});
    const day=new Date(`${date}T12:00:00`).getDay();if(!barber.workDays.includes(day))return json(res,200,{slots:[]});
    const [sh,sm]=barber.start.split(':').map(Number),[eh,em]=barber.end.split(':').map(Number);let slots=[];
    for(let t=sh*60+sm;t+service.duration<=eh*60+em;t+=30){const time=`${String(Math.floor(t/60)).padStart(2,'0')}:${String(t%60).padStart(2,'0')}`;const occ=db.bookings.some(b=>b.date===date&&b.barberId===barberId&&b.status!=='cancelled'&&overlaps(time,service.duration,b.time,b.duration));const blk=db.blockedSlots.some(b=>b.date===date&&b.barberId===barberId&&overlaps(time,service.duration,b.time,b.duration||30));if(!occ&&!blk)slots.push(time)}
    return json(res,200,{slots});
  }
  if(method==='POST'&&p==='/api/bookings'){
    const x=await parseBody(req);if(!x.serviceId||!x.barberId||!validDate(x.date)||!validTime(x.time)||!clean(x.name,80)||!clean(x.phone,30))return json(res,400,{error:'Preencha os dados obrigatórios corretamente.'});
    const db=readDb(),service=db.services.find(s=>s.id===x.serviceId&&s.active),barber=db.barbers.find(b=>b.id===x.barberId&&b.active);if(!service||!barber)return json(res,404,{error:'Serviço ou barbeiro indisponível.'});
    const occ=db.bookings.some(b=>b.date===x.date&&b.barberId===x.barberId&&b.status!=='cancelled'&&overlaps(x.time,service.duration,b.time,b.duration));const blk=db.blockedSlots.some(b=>b.date===x.date&&b.barberId===x.barberId&&overlaps(x.time,service.duration,b.time,b.duration||30));if(occ||blk)return json(res,409,{error:'Este horário acabou de ser ocupado. Escolha outro.'});
    const booking={id:crypto.randomUUID(),code:`TH-${Math.random().toString(36).slice(2,7).toUpperCase()}`,serviceId:x.serviceId,barberId:x.barberId,date:x.date,time:x.time,duration:service.duration,price:service.price,name:clean(x.name,80),phone:clean(x.phone,30),notes:clean(x.notes,240),status:'confirmed',createdAt:new Date().toISOString()};db.bookings.push(booking);writeDb(db);sendWhatsAppConfirmation(booking,service,barber,db.settings).catch(e=>console.error('Falha ao enviar confirmação pelo WhatsApp:',e.message));return json(res,201,{booking,service,barber});
  }
  if(method==='POST'&&p==='/api/admin/login'){const x=await parseBody(req),db=readDb();return x.password===db.settings.adminPassword?json(res,200,{ok:true}):json(res,401,{error:'Senha inválida.'});}
  if(p.startsWith('/api/admin/')&&!adminOK(req))return json(res,401,{error:'Senha inválida.'});
  if(method==='GET'&&p==='/api/admin/data'){const db=readDb(),{adminPassword,...settings}=db.settings;return json(res,200,{...db,settings});}
  let m=p.match(/^\/api\/admin\/bookings\/([^/]+)$/);if(method==='PATCH'&&m){const x=await parseBody(req),db=readDb(),b=db.bookings.find(v=>v.id===m[1]);if(!b)return json(res,404,{error:'Agendamento não encontrado.'});if(['confirmed','completed','cancelled'].includes(x.status))b.status=x.status;writeDb(db);return json(res,200,{booking:b});}if(method==='DELETE'&&m){const db=readDb(),index=db.bookings.findIndex(v=>v.id===m[1]);if(index<0)return json(res,404,{error:'Agendamento não encontrado.'});db.bookings.splice(index,1);writeDb(db);return json(res,200,{ok:true});}
  if(method==='POST'&&p==='/api/admin/block'){const x=await parseBody(req);if(!validDate(x.date)||!validTime(x.time)||!x.barberId)return json(res,400,{error:'Dados inválidos.'});const db=readDb(),block={id:crypto.randomUUID(),date:x.date,time:x.time,barberId:x.barberId,duration:Number(x.duration||30),reason:clean(x.reason||'Bloqueado pelo admin',100)};db.blockedSlots.push(block);writeDb(db);return json(res,201,block);}
  m=p.match(/^\/api\/admin\/block\/([^/]+)$/);if(method==='DELETE'&&m){const db=readDb();db.blockedSlots=db.blockedSlots.filter(v=>v.id!==m[1]);writeDb(db);return json(res,200,{ok:true});}
  if(method==='POST'&&p==='/api/admin/services'){const x=await parseBody(req),db=readDb(),s={id:crypto.randomUUID(),name:clean(x.name,80),description:clean(x.description,140),duration:Number(x.duration||30),price:Number(x.price||0),icon:clean(x.icon||'✂️',8),active:true};if(!s.name||s.duration<5||s.price<0)return json(res,400,{error:'Serviço inválido.'});db.services.push(s);writeDb(db);return json(res,201,s);}
  m=p.match(/^\/api\/admin\/services\/([^/]+)$/);if(method==='PATCH'&&m){const x=await parseBody(req),db=readDb(),s=db.services.find(v=>v.id===m[1]);if(!s)return json(res,404,{error:'Serviço não encontrado.'});['name','description','icon'].forEach(k=>{if(x[k]!==undefined)s[k]=clean(x[k],k==='description'?140:80)});['duration','price'].forEach(k=>{if(x[k]!==undefined)s[k]=Number(x[k])});if(x.active!==undefined)s.active=Boolean(x.active);writeDb(db);return json(res,200,s);}
  if(method==='POST'&&p==='/api/admin/barbers'){const x=await parseBody(req),db=readDb(),b={id:crypto.randomUUID(),name:clean(x.name,70),role:clean(x.role||'Barbeiro',70),initials:clean(x.initials||'TH',3).toUpperCase(),workDays:Array.isArray(x.workDays)?x.workDays:[1,2,3,4,5,6],start:x.start||'09:00',end:x.end||'19:00',active:true};if(!b.name)return json(res,400,{error:'Nome obrigatório.'});db.barbers.push(b);writeDb(db);return json(res,201,b);}
  m=p.match(/^\/api\/admin\/barbers\/([^/]+)$/);if(method==='PATCH'&&m){const x=await parseBody(req),db=readDb(),b=db.barbers.find(v=>v.id===m[1]);if(!b)return json(res,404,{error:'Barbeiro não encontrado.'});['name','role','initials','start','end'].forEach(k=>{if(x[k]!==undefined)b[k]=clean(x[k],70)});if(Array.isArray(x.workDays))b.workDays=x.workDays.map(Number);if(x.active!==undefined)b.active=Boolean(x.active);writeDb(db);return json(res,200,b);}
  if(method==='DELETE'&&m){const db=readDb(),hasBookings=db.bookings.some(v=>v.barberId===m[1]);if(hasBookings)return json(res,409,{error:'Não é possível excluir um barbeiro com agendamentos. Inative-o em Editar.'});const index=db.barbers.findIndex(v=>v.id===m[1]);if(index<0)return json(res,404,{error:'Barbeiro não encontrado.'});db.barbers.splice(index,1);writeDb(db);return json(res,200,{ok:true});}
  m=p.match(/^\/api\/admin\/clients\/(.+)$/);if(method==='DELETE'&&m){const phone=decodeURIComponent(m[1]),db=readDb(),before=db.bookings.length;db.bookings=db.bookings.filter(v=>v.phone!==phone);if(before===db.bookings.length)return json(res,404,{error:'Cliente não encontrado.'});writeDb(db);return json(res,200,{ok:true});}
  if(method==='PATCH'&&p==='/api/admin/settings'){const x=await parseBody(req),db=readDb();['businessName','tagline','phone','whatsapp','address','instagram','whatsappPhoneId','whatsappToken','whatsappApiVersion','whatsappTemplate','whatsappLanguage'].forEach(k=>{if(x[k]!==undefined)db.settings[k]=clean(x[k],k==='whatsappToken'?500:120)});if(x.whatsappEnabled!==undefined)db.settings.whatsappEnabled=Boolean(x.whatsappEnabled);if(x.adminPassword&&String(x.adminPassword).length>=4)db.settings.adminPassword=String(x.adminPassword);writeDb(db);return json(res,200,{ok:true});}
  return json(res,404,{error:'Rota não encontrada.'});
}

const server=http.createServer(async(req,res)=>{try{const url=new URL(req.url,`http://${req.headers.host||'localhost'}`);if(url.pathname.startsWith('/api/'))return await handleApi(req,res,url);if(serveFile(req,res,url.pathname))return;res.writeHead(404,{'Content-Type':'text/plain; charset=utf-8'});res.end('Página não encontrada');}catch(e){console.error(e);json(res,500,{error:'Erro interno do servidor.'});}});
server.listen(PORT,()=>{console.log(`Tio Higno Barbearia: http://localhost:${PORT}`);console.log(`Admin: http://localhost:${PORT}/admin`);});
